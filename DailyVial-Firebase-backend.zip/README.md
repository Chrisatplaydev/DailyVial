# DailyVial Firebase + Gemini backend

Prepared for project **dailyvial-418a9**. The existing GitHub Pages frontend stays in place. Firebase web registration and Google sign-in are configured in the console; deployment is not complete.

## Owner-only setup gates

1. In Firebase, upgrade this project from Spark to **Blaze** yourself. Google requires this for Cloud Functions deployment. Review current pricing and add billing alerts. Alerts are notifications, not hard spending caps. Do not enable services you have not reviewed.
2. Create a Cloud Firestore database in production mode, preferably `us-central1` to match the function. Location is a lasting choice; use a different region if your launch/data-residency requirements need it and update the function region too.
3. Install the official Firebase CLI with `npm install --global firebase-tools`, or use `npx firebase-tools`. Run `firebase login` yourself and review the Google consent screen. Do not paste login tokens into chat.
4. From this folder, run `firebase functions:secrets:set GEMINI_API_KEY --project dailyvial-418a9`. Enter the Gemini key in the terminal’s secret prompt yourself. Never put it in source, public environment files, chat, screenshots or GitHub. The public `web-config.json` is Firebase web-app configuration, not the Gemini secret.
5. In `functions`, run `npm ci` and `npm test`. Node.js 22 is the deployment runtime; the workspace validation ran on the installed Node 24 and loaded the Firebase SDKs successfully. Run emulator/live validation before launch.
6. Deploy with `firebase deploy --only firestore:rules,functions:dailyvialAI --project dailyvial-418a9`. Provide `GEMINI_MODEL` as an image-capable model available to your AI Studio account, `APP_ORIGIN=https://chrisatplaydev.github.io`, and leave `AI_TESTER_UID` blank unless explicitly granting the owner temporary testing access. The model must support generateContent with JSON output/schema.
7. Connect the returned HTTPS function URL through `DAILYVIAL_AI_ENDPOINT`, and public web config through `DAILYVIAL_FIREBASE_CONFIG`, then rebuild the frontend. Google sign-in from `chrisatplaydev.github.io` must be in Authentication → Settings → Authorized domains. Do not point the frontend at an undeployed service.

## What the prepared service does

- Verifies Firebase ID tokens on the server and checks the frontend origin.
- Uses Secret Manager for the Gemini key and a server-selected model.
- Supports `assistant` and `meal` modes, forwarding only the current question or photo + portion notes, never the journal.
- Uses structured meal output, validates nutrition/ranges and rejects invalid or incomplete responses. User review is required before a meal is saved locally.
- Uses Firestore transactions for access/allowance reservations and known-failure refunds. Client code cannot create entitlements or scan credits; Firestore rules deny all direct client access.
- Proposed limits: 5 helper questions/day on free access, 30 questions/day for verified Plus, 10 meal estimates/day for verified Plus. Free meal access requires a verified rewarded credit. A temporary owner tester UID also receives limited test access. Project-wide attempts are capped at 500/day; this is not a monetary spending cap. Failed upstream attempts still count against the project protection cap.
- Does not deploy checkout, verified payment/ad webhooks, cloud journal sync or background push scheduling. No account is granted Plus because of browser preview state.

## Before public launch

Review Google’s Gemini terms and data handling for the selected API tier before transmitting user photos or health-related text. Do not claim zero provider retention or medically accurate calorie counts. Publish updated privacy terms. Add App Check/abuse monitoring, assess quotas/costs, validate real-food estimates and clinical-boundary prompts, and test across devices. Reconcile stale reservations after an interrupted function before charging rewarded scan credits in production. Implement verified payment/ad events before selling AI access. Cloud backup/restore and reliable closed-app reminders remain separate deployment work; the current calendar export is the closed-app reminder alternative.

Official references: [Cloud Functions setup](https://firebase.google.com/docs/functions/get-started), [Secret Manager](https://firebase.google.com/docs/functions/config-env), [ID-token verification](https://firebase.google.com/docs/auth/admin/verify-id-tokens), [Gemini key security](https://ai.google.dev/gemini-api/docs/api-key), [Gemini generateContent](https://ai.google.dev/api/generate-content).
