const assert=require('node:assert/strict'),R=require('./rollout-policy.cjs');
assert(!R.isOwner({email:'owner@example.com',email_verified:false},'owner@example.com'));
assert(!R.isOwner({email:'other@example.com',email_verified:true},'owner@example.com'));
assert(R.isOwner({email:'OWNER@example.com',email_verified:true},'owner@example.com'));
assert(!R.allowed('owner-only',false));assert(R.allowed('owner-only',true));
assert(!R.allowed('typo',true));assert(!R.allowed('',true));assert(R.allowed('public',false));
for(const n of [0,-1,501,Infinity,'bad',null])assert.equal(R.dailyCap(n),50);
assert.equal(R.dailyCap('25'),25);
console.log('Rollout checks passed: verified owner only by default, unknown modes denied, daily cap bounded.');
