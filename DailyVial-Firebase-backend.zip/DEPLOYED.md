# Deployed AI pilot

Project: dailyvial-418a9
Function: dailyvialAI, codebase dailyvial, 2nd generation Node.js22, us-central1.
Endpoint: https://us-central1-dailyvial-418a9.cloudfunctions.net/dailyvialAI
Deployment confirmed successful. CLI first discovery attempt timed out; retry with FUNCTIONS_DISCOVERY_TIMEOUT=45 succeeded. Initial --only functions:dailyvialAI did not match named codebase; correct filter is functions:dailyvial.

GEMINI_API_KEY version1 is ENABLED. Value was not read or printed by agent. Deployed function accesses it through Secret Manager.
Owner-only rollout requires verified ID-token email dailyvialapp@gmail.com; public mode is not enabled. 50 project attempts/day, owner30 helper/10 meal per day, max1 instance, min0, concurrency2. Selected model gemini-3.5-flash-lite. No automatic Plus grants or payments.

Live checks: browser-origin OPTIONS204 with correct CORS origin; unsigned POST401. Neither check calls Gemini. Unit tests pass for Gemini validation/refund hooks and owner-only rollout boundaries. No signed-in Gemini/meal test yet.
Artifact Registry cleanup deletes deployment images older than7days. Existing function remains deployed.

Gemini billing is now active: Paid Tier1, $5 credit, auto-reload off, verified in AI Studio. Owner-account end-to-end tests and frontend connection are in progress.