// Only verified server-side ID-token claims may be passed here.
function isOwner(claims,email){return claims?.email_verified===true&&typeof email==='string'&&email.length>0&&claims.email?.toLowerCase()===email.toLowerCase();}
function allowed(mode,owner){return mode==='public'||(mode==='owner-only'&&owner===true);}
function dailyCap(value){const n=Number(value);return Number.isInteger(n)&&n>=1&&n<=500?n:50;}
module.exports={isOwner,allowed,dailyCap};
